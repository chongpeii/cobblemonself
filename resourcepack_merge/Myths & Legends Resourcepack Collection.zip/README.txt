License is a Creative Commons Attribution Non Commercial 4.0 International.
All original creators keep their respective rights.

Included in this pack are the following Texture packs:
- Genomons
- Legends & Myths
- Missing Legends
- Missing Mons
- Mystic Mons
- Pokemans Pack